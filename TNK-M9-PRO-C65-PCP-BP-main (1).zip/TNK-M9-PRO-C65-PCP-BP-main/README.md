# TNK-M9-PRO-C65-PCP-BP

Class 65 PCP boilerplate code

To run the project follow the below commands:

```
* git clone https://github.com/Tynker-Computer-Vision/TNK-M9-PRO-C65-PCP-BP.git
* cd TNK-M9-PRO-C65-PCP-BP
* python3 -m venv myenv
* source myenv/bin/activate ( For Linux & Mac )
* myenv/Scripts/activate.bat ( Windows )
* pip install -r requirements.txt
* python3 main.py
```

---
